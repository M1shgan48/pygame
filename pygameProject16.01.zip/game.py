import os
import sys
import pygame
from pygame.locals import *
import objects

class Display:
    def terminate(self):
        '''Метод удаляющий все спрайты'''
        for sprite in self.all_sprites:
            sprite.kill()

    def level_select_button_func(self, *args):
        '''Функция для кнопки перехода на экран выбора уровня'''
        self.terminate()
        self.level_select_render()

    def exit_button_func(self, *args):
        '''Функ1ция кнопки выхода из игры'''
        pygame.quit()
        exit(0)

    def back_button_func(self, *args):
        '''Функция кнопки возврата в главное меню'''
        self.terminate()
        self.menu_render()

    def level_button_func(self, *args):
        '''Функция кнопки выбора уровня'''
        self.terminate()
        self.level_render(args[0])

    def menu_render(self):
        '''Метод отображающий главное меню на экране'''
        size = width, height = 800, 600
        self.screen = pygame.display.set_mode(size)
        self.background = pygame.transform.scale(objects.load_image('fon_game.jpg'), size)

        self.all_sprites = pygame.sprite.Group()
        self.buttons = pygame.sprite.Group()
        self.tiles = pygame.sprite.Group()

        exit_button = objects.Button(700, 50, self.exit_button_func, self.all_sprites, self.buttons,
                                     image=pygame.transform.scale(objects.load_image('exit_button.png'), (50, 50)))
        level_select_button = objects.Button(350, 250, self.level_select_button_func, self.all_sprites, self.buttons,
                                     image=pygame.transform.scale(objects.load_image('start_button.png'), (100, 100)))

        self.buttons.draw(self.background)
        self.screen.blit(self.background, (0, 0))

    def level_select_render(self):
        '''Метод отображающий меню выбора уровня'''
        size = width, height = 800, 600
        self.screen = pygame.display.set_mode(size)
        self.background = pygame.transform.scale(objects.load_image('fon_game.jpg'), size)

        self.all_sprites = pygame.sprite.Group()
        self.buttons = pygame.sprite.Group()
        self.tiles = pygame.sprite.Group()

        back_button = objects.Button(50, 50, self.back_button_func, self.all_sprites, self.buttons,
                                     image=pygame.transform.scale(objects.load_image('back_button.png'), (150, 50)))
        level_one_button = objects.Button(150, 250, self.level_button_func, self.all_sprites, self.buttons,
                                          image=pygame.transform.scale(objects.load_image('start_button.png'), (50, 50)),
                                          level='first_level.txt')
        level_two_button = objects.Button(350, 250, self.level_button_func, self.all_sprites, self.buttons,
                                          image=pygame.transform.scale(objects.load_image('start_button.png'), (50, 50)),
                                          level='second_level.txt')
        level_three_button = objects.Button(550, 250, self.level_button_func, self.all_sprites, self.buttons,
                                          image=pygame.transform.scale(objects.load_image('start_button.png'), (50, 50)),
                                          level='third_level.txt')


        self.buttons.draw(self.background)
        self.screen.blit(self.background, (0, 0))

    def level_render(self, sample):
        with open(os.path.abspath(f'pygame_data/levels/{sample}'), 'r') as scheme:
            self.scheme = scheme.read().split()

        print(*self.scheme, sep='\n')

        size = width, height = 800, 800
        self.screen = pygame.display.set_mode(size)
        self.screen.fill((0, 150, 0))

        self.all_sprites = pygame.sprite.Group()
        self.buttons = pygame.sprite.Group()
        self.tiles = pygame.sprite.Group()

        back_button = objects.Button(601, 725, self.back_button_func, self.all_sprites, self.buttons,
                                     image=pygame.transform.scale(objects.load_image('back_button.png'), (199, 50)))

        images = {'*': 'grass.png',
                  'X': 'mount.jpg',
                  '0': 'water.png',
                  'C': 'castle.png',
                  'W': 'swamp.png'}
        types = {'grass.png': 'grass',
                 'water.png': 'water',
                 'mount.jpg': 'mount'}

        for row in range(len(self.scheme)):
            for col in range(len(self.scheme[row])):
                if images[self.scheme[row][col]] not in types:
                    type = 'NA'
                else:
                    type = types[images[self.scheme[row][col]]]
                tile = objects.Tile(type, pygame.transform.scale(objects.load_image(images[self.scheme[row][col]]), (50, 50)),
                                    col, row, self.all_sprites, self.tiles)

        self.all_sprites.draw(self.screen)



if __name__ == '__main__':
    pygame.init()
    current_display = Display()
    current_display.menu_render()
    running = True

    controls = {pygame.K_q : 'house.png',
                pygame.K_w : 'fisherman.png',
                pygame.K_e : 'church.png',
                pygame.K_x : 'grass.png'}

    while running:
        pygame.display.flip()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == pygame.BUTTON_LEFT:
                current_display.buttons.update(event.pos)
            if event.type == pygame.KEYDOWN:
                current_display.tiles.update(pygame.mouse.get_pos(), controls[event.key])
        current_display.all_sprites.draw(current_display.screen)
    pygame.quit()