#модуль для объектов и повсеместно использующихся функций
import os
import sys
import pygame

def load_image(name, colorkey=None):
    '''Функция выгрузки изображений'''
    fullname = os.path.join(os.path.abspath('pygame_data/images'), name)
    if not os.path.isfile(fullname):
        print(f"Файл с изображением '{fullname}' не найден")
        sys.exit()
    image = pygame.image.load(fullname)
    if not colorkey is None:
        image.set_colorkey(colorkey)
    return image

class Tile(pygame.sprite.Sprite):
    tile_width = tile_height = 50 #размеры клетки

    def __init__(self, image, pos_x, pos_y, *groups):
        super().__init__(*groups)
        self.pos_x = pos_x
        self.pos_y = pos_y
        self.image = image
        self.rect = self.image.get_rect().move(Tile.tile_width * pos_x, Tile.tile_height * pos_y)

    def update(self, new_img):
        self.image = image
        self.rect = self.image.get_rect().move(Tile.tile_width * self.pos_x, Tile.tile_height * self.pos_y)

class Button(pygame.sprite.Sprite):
    def __init__(self, x, y, onclickFunction, *group, buttonText='', font=None,
                 colors=('#FFFFFF', '#666666', '#333333'), width=50, height=50, image=None, **kwargs):
        super().__init__(*group)
        self.kwargs = kwargs

        #функция нажатия
        self.onclickFunction = onclickFunction

        #хитбокс кнопки
        if image is None:
            # цвета кнопки
            self.fillColors = {
                'normal': colors[0],
                'hover': colors[1],
                'pressed': colors[2],
            }
            self.color = self.fillColors['normal']

            self.image = pygame.Surface((self.width, self.height))
            self.rect = pygame.Rect(self.x, self.y, self.width, self.height)
            self.image.fill(self.color)
            self.textSurface = font.render(buttonText, True, (20, 20, 20))
        else:
            self.image = image
            self.rect = self.image.get_rect()
            self.rect.x = x
            self.rect.y = y

    def intersection(self, pos):
        '''метод позволяющий проверить находится ли данная точка на поверхности кнопки'''
        return self.rect.x <= pos[0] <= self.rect.x + self.rect.width and self.rect.y <= pos[1] <= self.rect.y + \
               self.rect.height

    def update(self, pos):
        '''обработка клика'''
        if self.intersection(pos):
            self.onclickFunction(self.kwargs['level'] if 'level' in self.kwargs else None)
